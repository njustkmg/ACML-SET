#!/usr/bin/env bash

python "$1" --cfg "$2" --model-dir "$3"

